module.exports = require('./')('west');
